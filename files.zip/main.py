"""
main.py — FastAPI entry point.
Run with: uvicorn main:app --reload --port 8000
"""

from pathlib import Path
from fastapi import FastAPI, UploadFile, File, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
import shutil
import tempfile

from database import init_db
from parser import parse_and_import
from enricher import enrich_all
from analytics import (
    get_positions,
    get_summary,
    get_portfolio_evolution,
    get_geo_allocation,
    get_sector_allocation,
    get_etf_evolution,
)

app = FastAPI(title="Portfolio Tracker", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# Serve frontend
FRONTEND_DIR = Path(__file__).parent / "frontend"
app.mount("/static", StaticFiles(directory=str(FRONTEND_DIR)), name="static")


@app.on_event("startup")
def startup():
    init_db()
    print("[SERVER] Portfolio tracker ready at http://localhost:8000")


@app.get("/")
def root():
    return FileResponse(str(FRONTEND_DIR / "index.html"))


# ─── Data import ──────────────────────────────────────────────────────────────

@app.post("/api/import")
async def import_csv(file: UploadFile = File(...)):
    """Upload a Trade Republic CSV and import transactions."""
    if not file.filename.endswith(".csv"):
        raise HTTPException(400, "Only CSV files are accepted")

    with tempfile.NamedTemporaryFile(delete=False, suffix=".csv") as tmp:
        shutil.copyfileobj(file.file, tmp)
        tmp_path = tmp.name

    result = parse_and_import(tmp_path)
    return result


@app.post("/api/enrich")
def enrich(force: bool = False):
    """Fetch ETF metadata (geo/sector) and price history for all known ISINs."""
    enrich_all(force=force)
    return {"status": "ok"}


# ─── Analytics endpoints ──────────────────────────────────────────────────────

@app.get("/api/summary")
def summary():
    return get_summary()


@app.get("/api/positions")
def positions():
    return get_positions()


@app.get("/api/evolution")
def evolution():
    return get_portfolio_evolution()


@app.get("/api/evolution/{isin}")
def etf_evolution(isin: str):
    return get_etf_evolution(isin)


@app.get("/api/geo")
def geo():
    return get_geo_allocation()


@app.get("/api/sectors")
def sectors():
    return get_sector_allocation()
