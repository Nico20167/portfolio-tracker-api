"""
Analytics — computes all portfolio metrics from the local DB.
All functions return plain dicts/lists (JSON-serialisable).
"""

import json
from datetime import date, datetime
from database import get_conn


# ─── helpers ──────────────────────────────────────────────────────────────────

def _latest_price(conn, isin: str) -> float | None:
    row = conn.execute(
        "SELECT close FROM prices WHERE isin = ? ORDER BY date DESC LIMIT 1",
        (isin,)
    ).fetchone()
    return row["close"] if row else None


def _etf_meta(conn, isin: str) -> dict:
    row = conn.execute(
        "SELECT * FROM etf_metadata WHERE isin = ?", (isin,)
    ).fetchone()
    if not row:
        return {}
    return dict(row)


# ─── positions ────────────────────────────────────────────────────────────────

def get_positions() -> list[dict]:
    """
    Returns current positions: one row per ISIN with total shares,
    avg cost, current price, current value, absolute and % gain.
    """
    with get_conn() as conn:
        rows = conn.execute("""
            SELECT
                isin,
                name,
                asset_class,
                account_type,
                SUM(shares)  AS total_shares,
                SUM(amount)  AS total_invested,
                COUNT(*)     AS nb_orders
            FROM transactions
            WHERE type = 'BUY'
            GROUP BY isin
            ORDER BY total_invested DESC
        """).fetchall()

        positions = []
        for r in rows:
            isin = r["isin"]
            price = _latest_price(conn, isin)
            avg_cost = r["total_invested"] / r["total_shares"] if r["total_shares"] else 0
            current_value = (price * r["total_shares"]) if price else None
            gain_abs = (current_value - r["total_invested"]) if current_value else None
            gain_pct = (gain_abs / r["total_invested"] * 100) if (gain_abs is not None and r["total_invested"]) else None

            positions.append({
                "isin": isin,
                "name": r["name"],
                "asset_class": r["asset_class"],
                "account_type": r["account_type"],
                "shares": round(r["total_shares"], 6),
                "avg_cost": round(avg_cost, 4),
                "total_invested": round(r["total_invested"], 2),
                "current_price": round(price, 4) if price else None,
                "current_value": round(current_value, 2) if current_value else None,
                "gain_abs": round(gain_abs, 2) if gain_abs is not None else None,
                "gain_pct": round(gain_pct, 2) if gain_pct is not None else None,
                "nb_orders": r["nb_orders"],
            })

    return positions


# ─── summary KPIs ─────────────────────────────────────────────────────────────

def get_summary() -> dict:
    """
    Top-level KPIs: total invested, current value, total gain, YTD gain,
    monthly breakdown of investments.
    """
    positions = get_positions()

    total_invested = sum(p["total_invested"] for p in positions)
    total_value = sum(p["current_value"] for p in positions if p["current_value"])
    total_gain_abs = total_value - total_invested if total_value else None
    total_gain_pct = (total_gain_abs / total_invested * 100) if (total_gain_abs and total_invested) else None

    # YTD: invested this calendar year
    current_year = date.today().year
    with get_conn() as conn:
        ytd_row = conn.execute("""
            SELECT COALESCE(SUM(amount), 0) AS ytd
            FROM transactions
            WHERE type = 'BUY'
              AND strftime('%Y', date) = ?
        """, (str(current_year),)).fetchone()
        ytd_invested = round(ytd_row["ytd"], 2)

        # Monthly invested (last 12 months)
        monthly_rows = conn.execute("""
            SELECT
                strftime('%Y-%m', date) AS month,
                SUM(amount) AS invested
            FROM transactions
            WHERE type = 'BUY'
              AND date >= date('now', '-12 months')
            GROUP BY month
            ORDER BY month
        """).fetchall()

    monthly = [
        {"month": r["month"], "invested": round(r["invested"], 2)}
        for r in monthly_rows
    ]

    return {
        "total_invested": round(total_invested, 2),
        "total_value": round(total_value, 2) if total_value else None,
        "total_gain_abs": round(total_gain_abs, 2) if total_gain_abs else None,
        "total_gain_pct": round(total_gain_pct, 2) if total_gain_pct else None,
        "ytd_invested": ytd_invested,
        "monthly_investments": monthly,
        "nb_positions": len(positions),
    }


# ─── portfolio evolution ───────────────────────────────────────────────────────

def get_portfolio_evolution() -> list[dict]:
    """
    Daily portfolio value from earliest transaction to today.
    For each date: sum of (shares_held × closing_price) for all positions.
    """
    with get_conn() as conn:
        # All buy transactions ordered by date
        tx_rows = conn.execute("""
            SELECT date, isin, shares, amount
            FROM transactions
            WHERE type = 'BUY'
            ORDER BY date
        """).fetchall()

        if not tx_rows:
            return []

        # All price dates available
        price_rows = conn.execute("""
            SELECT p.date, p.isin, p.close
            FROM prices p
            ORDER BY p.date
        """).fetchall()

    # Build cumulative shares per ISIN
    cumulative: dict[str, float] = {}
    tx_by_date: dict[str, list] = {}
    for r in tx_rows:
        tx_by_date.setdefault(r["date"], []).append(r)

    # Build price lookup: {isin: {date: close}}
    price_lookup: dict[str, dict[str, float]] = {}
    for r in price_rows:
        price_lookup.setdefault(r["isin"], {})[r["date"]] = r["close"]

    # Collect all unique price dates
    all_dates = sorted(set(r["date"] for r in price_rows))

    result = []
    for d in all_dates:
        # Apply any transactions on this date
        for tx in tx_by_date.get(d, []):
            cumulative[tx["isin"]] = cumulative.get(tx["isin"], 0) + tx["shares"]

        # Compute portfolio value: use most recent available price for each isin
        total = 0.0
        has_price = False
        for isin, shares in cumulative.items():
            # Find most recent price ≤ d
            prices_for_isin = price_lookup.get(isin, {})
            available = [dt for dt in prices_for_isin if dt <= d]
            if available:
                price = prices_for_isin[max(available)]
                total += shares * price
                has_price = True

        if has_price and cumulative:
            result.append({"date": d, "value": round(total, 2)})

    return result


# ─── allocation ───────────────────────────────────────────────────────────────

def _weighted_allocation(positions: list[dict], field: str) -> list[dict]:
    """
    Compute portfolio-level weighted allocation for geo or sector.
    field is 'geo_data' or 'sector_data'.
    """
    total_value = sum(
        p["current_value"] for p in positions
        if p["current_value"] and p["asset_class"] == "FUND"
    )
    if not total_value:
        return []

    aggregated: dict[str, float] = {}

    with get_conn() as conn:
        for p in positions:
            if p["asset_class"] != "FUND" or not p["current_value"]:
                continue
            meta = _etf_meta(conn, p["isin"])
            raw = meta.get(field)
            if not raw:
                continue
            allocation = json.loads(raw)
            weight = p["current_value"] / total_value

            for category, pct in allocation.items():
                # pct from justetf can be 0-100 or 0-1, normalise to 0-100
                val = pct if pct > 1 else pct * 100
                aggregated[category] = aggregated.get(category, 0) + weight * val

    # Sort by weight descending
    result = sorted(
        [{"name": k, "weight": round(v, 2)} for k, v in aggregated.items()],
        key=lambda x: x["weight"],
        reverse=True,
    )
    return result


def get_geo_allocation() -> list[dict]:
    return _weighted_allocation(get_positions(), "geo_data")


def get_sector_allocation() -> list[dict]:
    return _weighted_allocation(get_positions(), "sector_data")


# ─── per-ETF evolution ────────────────────────────────────────────────────────

def get_etf_evolution(isin: str) -> list[dict]:
    """Daily value for a single ETF position."""
    with get_conn() as conn:
        tx_rows = conn.execute("""
            SELECT date, shares FROM transactions
            WHERE isin = ? AND type = 'BUY'
            ORDER BY date
        """, (isin,)).fetchall()

        price_rows = conn.execute("""
            SELECT date, close FROM prices
            WHERE isin = ?
            ORDER BY date
        """, (isin,)).fetchall()

    if not tx_rows or not price_rows:
        return []

    cumulative_shares = 0.0
    tx_map = {}
    for r in tx_rows:
        tx_map[r["date"]] = tx_map.get(r["date"], 0) + r["shares"]

    price_map = {r["date"]: r["close"] for r in price_rows}
    all_dates = sorted(price_map.keys())

    result = []
    for d in all_dates:
        if d in tx_map:
            cumulative_shares += tx_map[d]
        if cumulative_shares > 0:
            result.append({
                "date": d,
                "value": round(cumulative_shares * price_map[d], 2)
            })

    return result
