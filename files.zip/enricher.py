"""
Enricher — fetches ETF composition (geo + sectors) from justetf.com
and current prices from yfinance.

justetf.com exposes undocumented but stable JSON endpoints used by their
own frontend. We call them directly with a standard browser User-Agent.
"""

import json
import time
import sqlite3
from datetime import datetime, date, timedelta
from typing import Optional

import requests
import yfinance as yf
from database import get_conn

JUSTETF_HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/124.0.0.0 Safari/537.36"
    ),
    "Accept": "application/json",
    "Accept-Language": "fr-FR,fr;q=0.9,en;q=0.8",
    "Referer": "https://www.justetf.com/",
}

# Maps ISIN to yfinance ticker (needed because yfinance doesn't resolve ISIN)
ISIN_TO_TICKER: dict[str, str] = {
    "IE0002XZSHO1": "SWRD.PA",    # iShares MSCI World Swap PEA
    "FR0013412020": "PAEEM.PA",   # Amundi PEA Emerging Markets ESG
    "FR0011871078": "PACH.PA",    # Amundi PEA China HSCEI
    "FR0011869320": "PAIN.PA",    # Amundi PEA India
    "FR0011550193": "ESE.PA",     # BNP Stoxx Europe 600
    "LU3047998896": "EDEF.PA",    # BNP Easy Bloomberg Europe Defense
    "US5801351017": "MCD",        # McDonald's
}


# ─── justetf helpers ──────────────────────────────────────────────────────────

def _justetf_search(isin: str) -> Optional[str]:
    """Returns the justetf ETF slug (e.g. 'IE00B4L5Y983') for a given ISIN."""
    url = f"https://www.justetf.com/api/etfs?isin={isin}&locale=fr&valutaCurrency=EUR"
    try:
        r = requests.get(url, headers=JUSTETF_HEADERS, timeout=10)
        r.raise_for_status()
        data = r.json()
        hits = data.get("hits", [])
        if hits:
            return hits[0].get("isin")
    except Exception as e:
        print(f"[ENRICHER] justetf search failed for {isin}: {e}")
    return None


def _fetch_country_allocation(isin: str) -> dict:
    """Fetch country breakdown from justetf for a given ISIN."""
    url = (
        f"https://www.justetf.com/api/etfs/{isin}/country-allocation"
        f"?locale=fr&valutaCurrency=EUR"
    )
    try:
        r = requests.get(url, headers=JUSTETF_HEADERS, timeout=10)
        r.raise_for_status()
        raw = r.json()
        # Response: list of {countryCode, country, weight}
        return {
            item["country"]: round(item["weight"], 4)
            for item in raw
            if "country" in item and "weight" in item
        }
    except Exception as e:
        print(f"[ENRICHER] country allocation failed for {isin}: {e}")
        return {}


def _fetch_sector_allocation(isin: str) -> dict:
    """Fetch sector breakdown from justetf for a given ISIN."""
    url = (
        f"https://www.justetf.com/api/etfs/{isin}/sector-allocation"
        f"?locale=fr&valutaCurrency=EUR"
    )
    try:
        r = requests.get(url, headers=JUSTETF_HEADERS, timeout=10)
        r.raise_for_status()
        raw = r.json()
        # Response: list of {sector, weight}
        return {
            item["sector"]: round(item["weight"], 4)
            for item in raw
            if "sector" in item and "weight" in item
        }
    except Exception as e:
        print(f"[ENRICHER] sector allocation failed for {isin}: {e}")
        return {}


# ─── yfinance helpers ─────────────────────────────────────────────────────────

def _fetch_current_price(isin: str) -> Optional[float]:
    ticker_sym = ISIN_TO_TICKER.get(isin)
    if not ticker_sym:
        print(f"[ENRICHER] No ticker mapped for {isin}")
        return None
    try:
        t = yf.Ticker(ticker_sym)
        info = t.fast_info
        price = info.last_price
        if price and price > 0:
            return round(float(price), 4)
    except Exception as e:
        print(f"[ENRICHER] yfinance price fetch failed for {isin} ({ticker_sym}): {e}")
    return None


def _fetch_price_history(isin: str, start: str) -> list[tuple[str, float]]:
    """Returns list of (date_str, close_price) from start date to today."""
    ticker_sym = ISIN_TO_TICKER.get(isin)
    if not ticker_sym:
        return []
    try:
        t = yf.Ticker(ticker_sym)
        hist = t.history(start=start, auto_adjust=True)
        return [
            (idx.strftime("%Y-%m-%d"), round(float(row["Close"]), 4))
            for idx, row in hist.iterrows()
        ]
    except Exception as e:
        print(f"[ENRICHER] price history failed for {isin}: {e}")
        return []


# ─── Public API ───────────────────────────────────────────────────────────────

def enrich_all(force: bool = False):
    """
    For every unique ISIN in the transactions table:
    - Fetch geo + sector composition from justetf (once per day unless force=True)
    - Fetch price history from yfinance
    """
    with get_conn() as conn:
        isins = [
            row[0] for row in
            conn.execute(
                "SELECT DISTINCT isin FROM transactions WHERE asset_class = 'FUND'"
            ).fetchall()
        ]

    today = date.today().isoformat()

    for isin in isins:
        print(f"\n[ENRICHER] Processing {isin}...")

        with get_conn() as conn:
            existing = conn.execute(
                "SELECT last_updated FROM etf_metadata WHERE isin = ?", (isin,)
            ).fetchone()

        needs_meta = force or (
            existing is None or existing["last_updated"] != today
        )

        if needs_meta:
            geo = _fetch_country_allocation(isin)
            time.sleep(0.5)
            sectors = _fetch_sector_allocation(isin)
            time.sleep(0.5)

            with get_conn() as conn:
                name_row = conn.execute(
                    "SELECT DISTINCT name FROM transactions WHERE isin = ? LIMIT 1",
                    (isin,)
                ).fetchone()
                name = name_row[0] if name_row else isin

                conn.execute("""
                    INSERT INTO etf_metadata (isin, name, ticker, last_updated, geo_data, sector_data)
                    VALUES (?, ?, ?, ?, ?, ?)
                    ON CONFLICT(isin) DO UPDATE SET
                        last_updated = excluded.last_updated,
                        geo_data     = excluded.geo_data,
                        sector_data  = excluded.sector_data
                """, (
                    isin, name,
                    ISIN_TO_TICKER.get(isin, ""),
                    today,
                    json.dumps(geo, ensure_ascii=False),
                    json.dumps(sectors, ensure_ascii=False),
                ))

            print(f"  geo countries: {len(geo)}, sectors: {len(sectors)}")
        else:
            print(f"  metadata already up-to-date")

        # Price history — find earliest transaction date for this ISIN
        with get_conn() as conn:
            first_date_row = conn.execute(
                "SELECT MIN(date) FROM transactions WHERE isin = ?", (isin,)
            ).fetchone()
            last_price_row = conn.execute(
                "SELECT MAX(date) FROM prices WHERE isin = ?", (isin,)
            ).fetchone()

        first_date = first_date_row[0] if first_date_row[0] else "2024-01-01"
        last_price_date = last_price_row[0]

        # Only fetch missing dates
        fetch_from = last_price_date or first_date
        if fetch_from < today:
            history = _fetch_price_history(isin, fetch_from)
            if history:
                with get_conn() as conn:
                    conn.executemany(
                        "INSERT OR REPLACE INTO prices (isin, date, close) VALUES (?,?,?)",
                        [(isin, d, p) for d, p in history]
                    )
                print(f"  prices: {len(history)} data points stored")

    print("\n[ENRICHER] Done.")


if __name__ == "__main__":
    enrich_all(force=False)
